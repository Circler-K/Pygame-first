FREE FONTS FOR THE LITTLE PEOPLE...
  *
Thank you for downloading my font!
These fonts are free to anyone who wants to use them.
All I ask is that you e-mail me :: yahoo@fontalicious.com :: and tell me where I can see it. If you use this font for print use, I would love a copy of whatever it is used for.

If you are going to redistribute my font, please include this Read Me text file and a link to my page. That's it! Actually, you don't have to link to my page, but I sure would like it!

Thanks for reading this. Have a super day!
All Fonts Copyright � 2001 Font-a-licious Fonts
Please refer to the "Usage Info" section of the website for any other information.
:::please visit http://www.fontalicious.com everyday!!

*********** TO INSTALL THESE MUTHAS IN YOUR COMPUTER ****************
FOR THE PC: Windows 3.1
Go to the control panel. Now go to fonts. You want to Add your font. Now tell the computer where font.TTF is, and click OK. The font should now be installed. 
Windows 95/98
Go to the control panel, either by double-clicking on your computer's icon and then opening the control panel, or by clicking on Start in the lower left corner, selecting Settings, and then selecting Control Panel. Double-click on Fonts. Inside are all the fonts currently installed on to install it. The font should now be installed. 
After these instructions,you will be a font installing pro. 
